import shap
import numpy as np
import pandas as pd
import random
import pickle
import math
import matplotlib.pyplot as plt

import tensorflow as tf
from tensorflow.keras import backend as K
from tensorflow.keras.models import Model
from tensorflow.keras.layers import *
from tensorflow.keras.models import load_model
from tensorflow.keras.utils import to_categorical
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold
from sklearn.preprocessing import OneHotEncoder, LabelEncoder

## ------------  the proposed neural network --------------------
## data loading and augment
data_file = '../dataset/SCADI.csv'
original_data = pd.read_csv(data_file)
data0 = original_data.loc[original_data['Gender'] == 0]
data0.loc[:, 'Gender'] = 1
data1 = original_data.loc[original_data['Gender'] == 1]
data1.loc[:, 'Gender'] = 0
extend_data = pd.concat([original_data, data0, data1], axis=0)

## dataset constructing for training and testing the neural network
class_name = extend_data['Classes']
label_encoder = LabelEncoder()
label_value = label_encoder.fit_transform(class_name)
enc = OneHotEncoder()
one_hot = enc.fit_transform(label_value.reshape(-1, 1))
y_onehot = one_hot.toarray()
x = extend_data.drop(labels=['Classes'], axis=1).values
y = [np.argmax(one_hot) for one_hot in y_onehot]
y = np.asarray(y)
y = y.reshape((-1, 1))
data_set = np.concatenate((x, y), axis=1)
y_list = []
for item in y:
    for i in item:
        y_list.append(i)
dict = {}
set = set(y_list)
for item in set:
    dict.update({item: y_list.count(item)})

x_data = x
y_data = np.array(y_list)
math.ceil(len(x_data)*0.9)

classes = [0, 1, 2, 3, 4, 5, 6]
x_train = x_data[0: math.ceil(len(x_data)*0.9)]
y_train = y_data[0: math.ceil(len(x_data)*0.9)]
x_test = x_data[math.ceil(len(x_data)*0.9) : ]
y_test = y_data[math.ceil(len(x_data)*0.9) : ]

num_classes = np.max(y_test) + 1
y_train_onehot = to_categorical(y_train, num_classes=num_classes)
y_test_onehot = to_categorical(y_test, num_classes=num_classes)

def data_generator(batch_size=64):
    while True:
        a = []
        p = []
        n = []
        for _ in range(batch_size):
            pos_neg = random.sample(classes, 2)
            positive_samples = random.sample(list(x_train[y_train == pos_neg[0]]), 2)
            negative_sample = random.choice(list(x_train[y_train == pos_neg[1]]))
            a.append(positive_samples[0])
            p.append(positive_samples[1])
            n.append(negative_sample)
        yield ([np.array(a), np.array(p), np.array(n)], np.zeros((batch_size, 1)).astype("float32"))

def triplet_loss(y_true, y_pred):
    embedding_size = 100 # the embeding size
    anchor_out = y_pred[:, 0: embedding_size]
    positive_out = y_pred[:, embedding_size: embedding_size*2]
    negative_out = y_pred[:, embedding_size*2: embedding_size*3]
    # tensorflow backend function
    pos_dist = K.sum(K.abs(anchor_out - positive_out), axis=1)  # l1 dist between anchor <-> positive (it can be changed to l2)
    neg_dist = K.sum(K.abs(anchor_out - negative_out), axis=1)  # l1 dist between anchor <-> negative

    probs = K.softmax([pos_dist, neg_dist], axis=0)
    return K.mean(K.abs(probs[0]) + K.abs(1.0 - probs[1]))

# the alpha in focal loss function
list_base = [2, 2, 2, 2, 2, 2, 2]
list_all = list(dict.values())
global alpha_0
alpha_0 = (np.array(list_all) - np.array(list_base))/sum(np.array(list_all) - np.array(list_base)) + 1
alpha_0.shape = 7,1

def focal_loss(y_true, y_pred):
    epsilon = 1.e-7
    gamma = 2.0
    alpha = tf.cast(alpha_0, tf.float32)

    y_true = tf.cast(y_true, tf.float32)
    y_pred = tf.clip_by_value(y_pred, epsilon, 1. - epsilon)
    y_t = tf.multiply(y_true, y_pred) + tf.multiply(1-y_true, 1-y_pred)
    ce = -tf.math.log(y_t)
    weight = tf.pow(tf.subtract(1., y_t), gamma)
    fl = tf.matmul(tf.multiply(weight, ce), alpha)
    loss = tf.reduce_mean(fl)
    return loss

def f1(y_true, y_pred):
    def recall(y_true, y_pred):
        """Recall metric.

        Only computes a batch-wise average of recall.

        Computes the recall, a metric for multi-label classification of
        how many relevant items are selected.
        """
        true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
        possible_positives = K.sum(K.round(K.clip(y_true, 0, 1)))
        recall = true_positives / (possible_positives + K.epsilon())
        return recall

    def precision(y_true, y_pred):
        """Precision metric.

        Only computes a batch-wise average of precision.

        Computes the precision, a metric for multi-label classification of
        how many selected items are relevant.
        """
        true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
        predicted_positives = K.sum(K.round(K.clip(y_pred, 0, 1)))
        precision = true_positives / (predicted_positives + K.epsilon())
        return precision

    precision = precision(y_true, y_pred)
    recall = recall(y_true, y_pred)
    return 2 * ((precision * recall) / (precision + recall + K.epsilon()))

# base model
embedding_size = 100
input_layer = Input((205))
x = Dense(200, activation="relu")(input_layer)
x = Dense(150, activation="relu")(x)
x = Dense(embedding_size, activation="relu")(x)
model = Model(input_layer, x)

# triplet loss model
triplet_model_a = Input((205))
triplet_model_p = Input((205))
triplet_model_n = Input((205))
triplet_model_out = Concatenate()([model(triplet_model_a), model(triplet_model_p), model(triplet_model_n)])
triplet_model = Model([triplet_model_a, triplet_model_p, triplet_model_n], triplet_model_out)

triplet_model.compile(loss=triplet_loss, optimizer="adam")
# triplet_model.fit_generator(data_generator(), steps_per_epoch=150, epochs=50)

# save and load the trained neural network
# triplet_model.save("triplet_network", save_format="tf")
triplet_model = load_model("triplet_network", compile=False)

# # the focal loss model (for classification)
# input_layer = Input((embedding_size))
# midlle_value = Dense(100, activation="relu")(input_layer)
# midlle_value = Dense(50, activation="relu")(midlle_value)
# model_output = Dense(7, activation="softmax")(midlle_value)
# class_model = Model(input_layer, model_output)
#
# embedings_train = triplet_model.layers[-2].predict(x_train, verbose=1)  # the embedding
# x_train = embedings_train
# y_train = y_train_onehot
# embedings_test = triplet_model.layers[-2].predict(x_test, verbose=1)
# x_test = embedings_test
# y_test = y_test_onehot
# class_model.compile(loss=focal_loss, optimizer="adam", metrics=['accuracy', f1])
# history = class_model.fit(x_train, y_train, epochs=50, batch_size=32, verbose=2, validation_data=(x_test, y_test))
#
# # save and load the trained neural network
# class_model.save("class_network", save_format="tf")
class_model = load_model("class_network", compile=False)


embedding_layer = model.output
class_output = class_model(embedding_layer)


full_model = Model(inputs=model.input, outputs=class_output)
# full_model.summary()



explainer = shap.Explainer(full_model, x_train)

shap_values = explainer(x_test)

print(x_test.shape)
print(np.array(shap_values).shape)


shap_values_array = shap_values.values
mean_shap_values = np.mean(np.abs(shap_values_array), axis=2)


plt.figure(figsize=(10, 6))
shap.summary_plot(mean_shap_values, x_test, show=False)

plt.title("Feature Importance Based on SHAP Values", fontsize=16)
plt.xlabel("SHAP Value (Impact on Model Output)", fontsize=14)
plt.ylabel("Features", fontsize=14)

plt.savefig("shap_mean.png", dpi=600, bbox_inches='tight')


for i in range(7):
    print(f"Saving SHAP summary plot for class {i}...")

    plt.figure()

    shap.summary_plot(shap_values[:, :, i], x_test, show=False)

    plt.xlabel("SHAP Value (Impact on Model Output)", fontsize=14)
    plt.ylabel("Features", fontsize=14)
    plt.title(f"Feature Importance for Class {(i+1)} (SHAP Values)", fontsize=16)

    plt.savefig(f"shap_summary_class_{(i+1)}.png", dpi=600, bbox_inches="tight")