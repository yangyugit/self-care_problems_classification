import numpy as np
import pickle
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick


with open('final_method_56_validation.pkl', 'rb') as file:
    loss = pickle.load(file)

    val_acc = pickle.load(file)
    val_acc_list = pickle.load(file)

    val_f1 = pickle.load(file)
    val_f1_list = pickle.load(file)

    val_recall = pickle.load(file)
    val_recall_list = pickle.load(file)

    val_precision = pickle.load(file)
    val_precision_list = pickle.load(file)


val_performance1 = np.array(val_acc_list)
acc_mean = np.mean(val_performance1)
acc_std = np.std(val_performance1)
print("test acc mean is: %f" % acc_mean)

val_performance2 = np.array(val_f1_list)
f1_mean = np.mean(val_performance2)
f1_std = np.std(val_performance2)
print("test f1 mean is: %f" % f1_mean)

val_performance3 = np.array(val_recall_list)
recall_mean = np.mean(val_performance3)
recall_std = np.std(val_performance3)
print("test recall mean is: %f" %recall_mean)

val_performance4 = np.array(val_precision_list)
precision_mean = np.mean(val_performance4)
precision_std = np.std(val_performance4)
print("test precision mean is: %f" %precision_mean)

print(val_performance1)


plt.figure(num=1)
ax = plt.gca()
ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
plt.plot(val_performance1 * 100,  marker='o', alpha=0.8 ,linestyle='-', linewidth=2.5, color='r', markeredgecolor='darkred',markersize='5',markeredgewidth=7)
plt.xlabel('Number of experimental runs', fontsize=18)
plt.ylabel('Accuracy (%)', fontsize=18)
plt.xlim(0,100)
plt.ylim(0,100)
plt.xticks(rotation=0)
plt.tick_params(labelsize=18)
plt.savefig('acc_val_56', bbox_inches='tight')
plt.clf()


plt.figure(num=2)
ax = plt.gca()
ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
plt.plot(val_performance2,  marker='o',  alpha=0.8 , linestyle='-', linewidth=2.5, color='b', markeredgecolor='midnightblue',markersize='5',markeredgewidth=7)
plt.xlabel('Number of experimental runs', fontsize=18)
plt.ylabel('Precision', fontsize=18)
plt.xlim(0,100)
plt.ylim(0,1)
plt.xticks(rotation=0)
plt.tick_params(labelsize=18)
plt.savefig('pre_val_56', bbox_inches='tight')
plt.clf()

plt.figure(num=3)
ax = plt.gca()
ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
plt.plot(val_performance3,  marker='o',  alpha=0.8 , linestyle='-', linewidth=2.5, color='g', markeredgecolor='darkgreen',markersize='5',markeredgewidth=7)
plt.xlabel('Number of experimental runs', fontsize=18)
plt.ylabel('Recall', fontsize=18)
plt.xlim(0,100)
plt.ylim(0,1)
plt.xticks(rotation=0)
plt.tick_params(labelsize=18)
plt.savefig('recall_val_56', bbox_inches='tight')
plt.clf()

plt.figure(num=4)
ax = plt.gca()
ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
plt.plot(val_performance4,  marker='o',  alpha=0.8 , linestyle='-', linewidth=2.5, color='plum', markeredgecolor='purple',markersize='5',markeredgewidth=7)
plt.xlabel('Number of experimental runs', fontsize=18)
plt.ylabel('F1 score', fontsize=18)
plt.xlim(0,100)
plt.ylim(0,1)
plt.xticks(rotation=0)
plt.tick_params(labelsize=18)
plt.savefig('f1score_val_56', bbox_inches='tight')
plt.clf()