import numpy as np
import pickle
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick

with open('final_method_56_validation.pkl', 'rb') as file:
    loss = pickle.load(file)

    val_acc = pickle.load(file)
    val_acc_list = pickle.load(file)

    val_f1 = pickle.load(file)
    val_f1_list = pickle.load(file)

    val_recall = pickle.load(file)
    val_recall_list = pickle.load(file)

    val_precision = pickle.load(file)
    val_precision_list = pickle.load(file)

acc_56 = val_acc_list
pre_56 = val_precision_list
recall_56 = val_recall_list
f1_56 = val_f1_list

print('----------------56 dimensions-------------- :')
print(acc_56)
print("test acc mean is: %f" % np.mean(acc_56))
print("test acc std is: %f" % np.std(acc_56))
print(pre_56)
print("test precision mean is: %f" % np.mean(pre_56))
print("test precision std is: %f" % np.std(pre_56))
print(recall_56)
print("test recall mean is: %f" % np.mean(recall_56))
print("test recall std is: %f" % np.std(recall_56))
print(f1_56)
print("test f1 score mean is: %f" % np.mean(f1_56))
print("test f1 score std is: %f" % np.std(f1_56))



with open('final_method_34_validation.pkl', 'rb') as file:
    loss = pickle.load(file)

    val_acc = pickle.load(file)
    val_acc_list = pickle.load(file)

    val_f1 = pickle.load(file)
    val_f1_list = pickle.load(file)

    val_recall = pickle.load(file)
    val_recall_list = pickle.load(file)

    val_precision = pickle.load(file)
    val_precision_list = pickle.load(file)

acc_34 = val_acc_list
pre_34 = val_precision_list
recall_34 = val_recall_list
f1_34 = val_f1_list

print('------------------34 dimensions -----------------:')
print(acc_34)
print("test acc mean is: %f" % np.mean(acc_34))
print("test acc std is: %f" % np.std(acc_34))
print(pre_34)
print("test precision mean is: %f" % np.mean(pre_34))
print("test precision std is: %f" % np.std(pre_34))
print(recall_34)
print("test recall mean is: %f" % np.mean(recall_34))
print("test recall std is: %f" % np.std(recall_34))
print(f1_34)
print("test f1 score mean is: %f" % np.mean(f1_34))
print("test f1 score std is: %f" % np.std(f1_34))

with open('final_method_205_validation.pkl', 'rb') as file:
    loss = pickle.load(file)

    val_acc = pickle.load(file)
    val_acc_list = pickle.load(file)

    val_f1 = pickle.load(file)
    val_f1_list = pickle.load(file)

    val_recall = pickle.load(file)
    val_recall_list = pickle.load(file)

    val_precision = pickle.load(file)
    val_precision_list = pickle.load(file)

acc_205 = val_acc_list
pre_205 = val_precision_list
recall_205 = val_recall_list
f1_205 = val_f1_list

print('------------------205 dimensions -----------------:')
print(acc_205)
print("test acc mean is: %f" % np.mean(acc_205))
print("test acc std is: %f" % np.std(acc_205))
print(pre_205)
print("test precision mean is: %f" % np.mean(pre_205))
print("test precision std is: %f" % np.std(pre_205))
print(recall_205)
print("test recall mean is: %f" % np.mean(recall_205))
print("test recall std is: %f" % np.std(recall_205))
print(f1_205)
print("test f1 score mean is: %f" % np.mean(f1_205))
print("test f1 score std is: %f" % np.std(f1_205))


plt.rc('font',family='Times New Roman')

plt.figure(num=1, dpi=600)
ax = plt.gca()
ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
plt.plot(np.array(acc_205) * 100,  marker='o', alpha=0.8 ,linestyle='-', linewidth=2.5, color='r', markeredgecolor='darkred',markersize='5',markeredgewidth=7)
plt.plot(np.array(acc_34) * 100,  marker='o', alpha=0.8 ,linestyle='-', linewidth=2.5, color='b', markeredgecolor='midnightblue',markersize='5',markeredgewidth=7)
plt.plot(np.array(acc_56) * 100,  marker='o', alpha=0.8 ,linestyle='-', linewidth=2.5, color='g', markeredgecolor='darkgreen',markersize='5',markeredgewidth=7)
plt.xlabel('Number of experimental runs', fontsize=18)
plt.ylabel('Accuracy (%)', fontsize=18)
plt.legend(loc='best', labels=['205 dimensions', '34 dimensions', '56 dimensions'], fontsize=18)
plt.xlim(0,100)
plt.ylim(0,100)
plt.xticks(rotation=0)
plt.tick_params(labelsize=18)
plt.savefig('acc_val', bbox_inches='tight')
plt.clf()


plt.figure(num=2, dpi=600)
ax = plt.gca()
ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
plt.plot(np.array(pre_205),  marker='o', alpha=0.8 ,linestyle='-', linewidth=2.5, color='r', markeredgecolor='darkred',markersize='5',markeredgewidth=7)
plt.plot(np.array(pre_34),  marker='o', alpha=0.8 ,linestyle='-', linewidth=2.5, color='b', markeredgecolor='midnightblue',markersize='5',markeredgewidth=7)
plt.plot(np.array(pre_56) ,  marker='o', alpha=0.8 ,linestyle='-', linewidth=2.5, color='g', markeredgecolor='darkgreen',markersize='5',markeredgewidth=7)
plt.xlabel('Number of experimental runs', fontsize=18)
plt.ylabel('Presion', fontsize=18)
plt.xlim(0,100)
plt.ylim(0,1)
plt.xticks(rotation=0)
plt.tick_params(labelsize=18)
plt.savefig('pre_val', bbox_inches='tight')
plt.clf()


plt.figure(num=3, dpi=600)
ax = plt.gca()
ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
plt.plot(np.array(recall_205),  marker='o', alpha=0.8 ,linestyle='-', linewidth=2.5, color='r', markeredgecolor='darkred',markersize='5',markeredgewidth=7)
plt.plot(np.array(recall_34),  marker='o', alpha=0.8 ,linestyle='-', linewidth=2.5, color='b', markeredgecolor='midnightblue',markersize='5',markeredgewidth=7)
plt.plot(np.array(recall_56) ,  marker='o', alpha=0.8 ,linestyle='-', linewidth=2.5, color='g', markeredgecolor='darkgreen',markersize='5',markeredgewidth=7)
plt.xlabel('Number of experimental runs', fontsize=18)
plt.ylabel('Recall', fontsize=18)
plt.xlim(0,100)
plt.ylim(0,1)
plt.xticks(rotation=0)
plt.tick_params(labelsize=18)
plt.savefig('recall_val', bbox_inches='tight')
plt.clf()

plt.figure(num=4, dpi=600)
ax = plt.gca()
ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
plt.plot(np.array(f1_205),  marker='o', alpha=0.8 ,linestyle='-', linewidth=2.5, color='r', markeredgecolor='darkred',markersize='5',markeredgewidth=7)
plt.plot(np.array(f1_34),  marker='o', alpha=0.8 ,linestyle='-', linewidth=2.5, color='b', markeredgecolor='midnightblue',markersize='5',markeredgewidth=7)
plt.plot(np.array(f1_56),  marker='o', alpha=0.8 ,linestyle='-', linewidth=2.5, color='g', markeredgecolor='darkgreen',markersize='5',markeredgewidth=7)
plt.xlabel('Number of experimental runs', fontsize=18)
plt.ylabel('F1 score', fontsize=18)
plt.xlim(0,100)
plt.ylim(0,1)
plt.xticks(rotation=0)
plt.tick_params(labelsize=18)
plt.savefig('F1_val', bbox_inches='tight')
plt.clf()
