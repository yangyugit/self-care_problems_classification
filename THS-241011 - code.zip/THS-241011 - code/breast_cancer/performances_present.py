import numpy as np
import pickle
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick

with open('performances.pkl', 'rb') as file:
    loss = pickle.load(file)

    val_acc = pickle.load(file)
    val_acc_list = pickle.load(file)

    val_f1 = pickle.load(file)
    val_f1_list = pickle.load(file)

    val_recall = pickle.load(file)
    val_recall_list = pickle.load(file)

    val_precision = pickle.load(file)
    val_precision_list = pickle.load(file)

val_performance1 = np.array(val_acc_list)
acc_mean = np.mean(val_performance1)
acc_std = np.std(val_performance1)
print("Best acc mean is: %f" % max(val_performance1))
print("test acc mean is: %f" % acc_mean)
print("test acc SD is: %f" % acc_std)

val_performance4 = np.array(val_precision_list)
precision_mean = np.mean(val_performance4)
precision_std = np.std(val_performance4)
print("Best precision mean is: %f" % max(val_performance4))
print("test precision mean is: %f" % precision_mean)
print("test precision std is: %f" % precision_std)

val_performance3 = np.array(val_recall_list)
recall_mean = np.mean(val_performance3)
recall_std = np.std(val_performance3)
print("Best recall mean is: %f" % max(val_performance3))
print("test recall mean is: %f" % recall_mean)
print("test recall std is: %f" % recall_std)

val_performance2 = np.array(val_f1_list)
f1_mean = np.mean(val_performance2)
f1_std = np.std(val_performance2)
print("Best f1 score mean is: %f" % max(val_performance2))
print("test f1 score mean is: %f" % f1_mean)
print("test f1 score std is: %f" % f1_std)

# plt.rc('font',family='Times New Roman')
# plt.figure(num=1, dpi=600)
# ax = plt.gca()
# ax.yaxis.set_major_formatter(mtick.FormatStrFormatter('%.2f'))
# plt.plot(np.array(acc_205) * 100,  marker='o', alpha=0.8 ,linestyle='-', linewidth=2.5, color='r', markeredgecolor='darkred',markersize='5',markeredgewidth=7)
# plt.plot(np.array(acc_34) * 100,  marker='o', alpha=0.8 ,linestyle='-', linewidth=2.5, color='b', markeredgecolor='midnightblue',markersize='5',markeredgewidth=7)
# plt.plot(np.array(acc_56) * 100,  marker='o', alpha=0.8 ,linestyle='-', linewidth=2.5, color='g', markeredgecolor='darkgreen',markersize='5',markeredgewidth=7)
# plt.xlabel('Number of experimental runs', fontsize=18)
# plt.ylabel('Accuracy (%)', fontsize=18)
# plt.legend(loc='best', labels=['205 dimensions', '34 dimensions', '56 dimensions'], fontsize=18)
# plt.xlim(0,100)
# plt.ylim(0,100)
# plt.xticks(rotation=0)
# plt.tick_params(labelsize=18)
# plt.savefig('acc_val', bbox_inches='tight')
# plt.clf()