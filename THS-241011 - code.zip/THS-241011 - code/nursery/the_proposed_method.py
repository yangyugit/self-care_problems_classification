import pandas as pd
import numpy as np
import random
import pickle
import matplotlib.pyplot as plt
import time
import seaborn as sns

import tensorflow as tf
from tensorflow.keras import backend as K
from tensorflow.keras.models import Model
from tensorflow.keras.layers import *
from tensorflow.keras.models import load_model
from tensorflow.keras.utils import to_categorical
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold
from sklearn.preprocessing import OneHotEncoder, LabelEncoder, StandardScaler

## data loading
data_file = '../dataset/nursery.data'
df = pd.read_csv(data_file, header=None)
print(len(df))
print(df)

# data construction
column_mappings = {
    0: {'usual': 0, 'pretentious': 1, 'great_pret': 2},
    1: {'proper': 0, 'less_proper': 1, 'improper': 2, 'critical': 3, 'very_crit': 4},
    2: {'complete': 0, 'completed': 1, 'incomplete': 2, 'foster': 3},
    3: {'1': 0, '2': 1, '3': 2, 'more': 3},
    4: {'convenient': 0, 'less_conv': 1, 'critical': 2},
    5: {'convenient': 0, 'inconv': 1},
    6: {'nonprob': 0, 'slightly_prob': 1, 'problematic': 2},
    7: {'recommended': 0, 'priority': 1, 'not_recom': 2},
    8: {'not_recom': 0, 'recommend': 1, 'very_recom': 2, 'priority': 3, 'spec_prior': 4}
}

# 应用映射
for col, mapping in column_mappings.items():
    df[col] = df[col].map(mapping)

# 显示前 5 行转换后的数据
print(df.head())

# 拆分特征（X）和标签（y）
x_data = df.iloc[:, :-1].values  #
y_data = df.iloc[:, -1].values   #

# 进行 One-Hot 编码（因为 y 是分类变量）
encoder = OneHotEncoder(sparse=False)
y_onehot = encoder.fit_transform(y_data.reshape(-1, 1))

# 数据归一化（标准化）
scaler = StandardScaler()
x_data = scaler.fit_transform(x_data)

## data view
# 统计 y 中每个类别的数量
class_counts = pd.Series(y_data).value_counts()
# 绘制饼图
plt.figure(figsize=(8, 8))
plt.pie(class_counts, labels=class_counts.index, autopct='%1.1f%%', startangle=140, colors=sns.color_palette("pastel"))
plt.title("Class Distribution of y")
# 保存图像为 600 DPI 的 PNG 文件
plt.savefig("class_distribution.png", dpi=600, bbox_inches='tight')

# select the base data of every kind, that every kind contains at least 2 instances
index0 = [(random.sample(list(np.where(y_data==0)[0]), 2))]
index1 = [(random.sample(list(np.where(y_data==1)[0]), 2))]
index2 = [(random.sample(list(np.where(y_data==2)[0]), 2))]
index3 = [(random.sample(list(np.where(y_data==3)[0]), 2))]
index4 = [(random.sample(list(np.where(y_data==4)[0]), 2))]
# 这个是每次必须要挑选的数据
index_0 = np.concatenate((index0,index1,index2,index3,index4), axis=1)[0]
x_index0 = x_data[index_0]
y_index0 = y_data[index_0]
y_onehot_index0 = y_onehot[index_0]

# 剩下的数据在这里面进行挑选区分 training dataset 和 testing dataset
x_left = np.delete(x_data, index_0, axis=0)
y_left = np.delete(y_data, index_0, axis=0)
y_onehot_left = np.delete(y_onehot, index_0, axis=0)

def data_generator(batch_size=1000):
    classes = [0, 1, 2, 3, 4]
    while True:
        a = []
        p = []
        n = []
        for _ in range(batch_size):
            pos_neg = random.sample(classes, 2)
            positive_samples = random.sample(list(x_train[y_train == pos_neg[0]]), 2)
            negative_sample = random.choice(list(x_train[y_train == pos_neg[1]]))
            a.append(positive_samples[0])
            p.append(positive_samples[1])
            n.append(negative_sample)
        yield ([np.array(a), np.array(p), np.array(n)], np.zeros((batch_size, 1)).astype("float32"))

def triplet_loss(y_true, y_pred):
    embedding_size = 100
    anchor_out = y_pred[:, 0: embedding_size]
    positive_out = y_pred[:, embedding_size: embedding_size*2]
    negative_out = y_pred[:, embedding_size*2: embedding_size*3]
    # tensorflow backend function
    pos_dist = K.sum(K.abs(anchor_out - positive_out), axis=1)
    neg_dist = K.sum(K.abs(anchor_out - negative_out), axis=1)

    probs = K.softmax([pos_dist, neg_dist], axis=0)
    return K.mean(K.abs(probs[0]) + K.abs(1.0 - probs[1]))

## alpha_0 for the focal loss function
# 按类别从小到大排序
sorted_class_counts = class_counts.sort_index()
# 获取类别标签的数组
sorted_classes = sorted_class_counts.index.to_numpy()
# 获取对应类别的样本数数组
sorted_counts = sorted_class_counts.values  # list_all
list_base = [2, 2, 2, 2, 2]
global alpha_0
alpha_0 = (np.array(sorted_counts) - np.array(list_base))/sum(np.array(sorted_counts) - np.array(list_base)) + 1
alpha_0.shape = 5,1
def focal_loss(y_true, y_pred):
    epsilon = 1.e-7
    gamma = 2.0
    alpha = tf.cast(alpha_0, tf.float32)

    y_true = tf.cast(y_true, tf.float32)
    y_pred = tf.clip_by_value(y_pred, epsilon, 1. - epsilon)
    y_t = tf.multiply(y_true, y_pred) + tf.multiply(1-y_true, 1-y_pred)
    ce = -tf.math.log(y_t)
    weight = tf.pow(tf.subtract(1., y_t), gamma)
    fl = tf.matmul(tf.multiply(weight, ce), alpha)
    loss = tf.reduce_mean(fl)
    return loss

def f1(y_true, y_pred):
    def recall(y_true, y_pred):
        """Recall metric.

        Only computes a batch-wise average of recall.

        Computes the recall, a metric for multi-label classification of
        how many relevant items are selected.
        """
        true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
        possible_positives = K.sum(K.round(K.clip(y_true, 0, 1)))
        recall = true_positives / (possible_positives + K.epsilon())
        return recall

    def precision(y_true, y_pred):
        """Precision metric.

        Only computes a batch-wise average of precision.

        Computes the precision, a metric for multi-label classification of
        how many selected items are relevant.
        """
        true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
        predicted_positives = K.sum(K.round(K.clip(y_pred, 0, 1)))
        precision = true_positives / (predicted_positives + K.epsilon())
        return precision

    precision = precision(y_true, y_pred)
    recall = recall(y_true, y_pred)
    return 2 * ((precision * recall) / (precision + recall + K.epsilon()))

def recall_score(y_true, y_pred):
    """Recall metric.

    Only computes a batch-wise average of recall.

    Computes the recall, a metric for multi-label classification of
    how many relevant items are selected.
    """
    true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
    possible_positives = K.sum(K.round(K.clip(y_true, 0, 1)))
    recall = true_positives / (possible_positives + K.epsilon())
    return recall

def precision_score(y_true, y_pred):
    """Precision metric.

    Only computes a batch-wise average of precision.

    Computes the precision, a metric for multi-label classification of
    how many selected items are relevant.
    """
    true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
    predicted_positives = K.sum(K.round(K.clip(y_pred, 0, 1)))
    precision = true_positives / (predicted_positives + K.epsilon())
    return precision

val_acc_list = []; val_f1_list = []; # record the performance
val_recall_list = []; val_precision_list=[];

kf = KFold(n_splits=9, shuffle=True, random_state=1)

for train_index, test_index in kf.split(range(0, (len(x_data)-2*5))):
    x_train = x_left[train_index]
    x_train = np.concatenate((x_index0, x_train), axis=0)
    x_test = x_left[test_index]

    y_train = y_left[train_index]
    y_train = np.concatenate((y_index0, y_train), axis=0)
    y_test = y_left[test_index]

    y_train_onehot = y_onehot_left[train_index]
    y_train_onehot = np.concatenate((y_onehot_index0, y_train_onehot), axis=0)
    y_test_onehot = y_onehot_left[test_index]

    # the base network
    embedding_size = 100    # set the embedding dimension
    input_layer = Input((8))
    x = Dense(200, activation="relu")(input_layer)
    x = Dense(150, activation="relu")(x)
    x = Dense(100, activation="relu")(x) # embedding size=100
    model = Model(input_layer, x)

    # the triplet loss model (for embedding)
    triplet_model_a = Input((8))
    triplet_model_p = Input((8))
    triplet_model_n = Input((8))
    triplet_model_out = Concatenate()([model(triplet_model_a), model(triplet_model_p), model(triplet_model_n)])
    triplet_model = Model([triplet_model_a, triplet_model_p, triplet_model_n], triplet_model_out)


    triplet_model.compile(loss=triplet_loss, optimizer="adam")

    start_time = time.time()    # start time
    triplet_model.fit_generator(data_generator(), steps_per_epoch=10, epochs=32, verbose=2)
    end_time = time.time()      # end time
    print(f"Training time of the embedding neural network: {end_time - start_time:.4f} seconds")

    # # save and load the trained neural network
    # triplet_model.save("triplet_network", save_format="tf")
    # triplet_model = load_model("triplet_network", compile=False)

    # the focal loss model (for classification)
    input_layer = Input((embedding_size))
    midlle_value = Dense(100, activation="relu")(input_layer)
    midlle_value = Dense(50, activation="relu")(midlle_value)
    model_output = Dense(5, activation="softmax")(midlle_value) # the model output
    class_model = Model(input_layer, model_output)

    embedings_train = triplet_model.layers[-2].predict(x_train, verbose=1)  # the embedding
    x_train = embedings_train
    y_train =  y_train_onehot

    embedings_test = triplet_model.layers[-2].predict(x_test, verbose=1)

    x_test = embedings_test
    y_test = y_test_onehot

    class_model.compile(loss=focal_loss, optimizer="adam", metrics=['accuracy', recall_score, precision_score, f1])
    history = class_model.fit(x_train, y_train, epochs=50, batch_size=32, verbose=2, validation_data=(x_test, y_test))

    # see the accuracy
    loss = history.history['loss']
    val_acc = history.history['val_accuracy']
    val_f1 = history.history['val_f1']
    val_recall = history.history['val_recall_score']
    val_precision = history.history['val_precision_score']

    val_acc_list.append(val_acc[-1])    # record
    val_f1_list.append(val_f1[-1])
    val_recall_list.append(val_recall[-1])
    val_precision_list.append(val_precision[-1])

# 计算十折测试后 模型在测试集上的表现能力
val_performance1 = np.array(val_acc_list)
acc_mean = np.mean(val_performance1)
acc_std = np.std(val_performance1)
print("test acc mean is: %f" % acc_mean)

val_performance2 = np.array(val_f1_list)
f1_mean = np.mean(val_performance2)
f1_std = np.std(val_performance2)
print("test f1 mean is: %f" % f1_mean)

val_performance3 = np.array(val_recall_list)
recall_mean = np.mean(val_performance3)
recall_std = np.std(val_performance3)
print("test recall mean is: %f" %recall_mean)

val_performance4 = np.array(val_precision_list)
precision_mean = np.mean(val_performance4)
precision_std = np.std(val_performance4)
print("test precision mean is: %f" %precision_mean)

with open('performances.pkl', 'wb') as file:
    pickle.dump(loss, file)

    pickle.dump(val_acc, file)
    pickle.dump(val_acc_list, file)

    pickle.dump(val_f1, file)
    pickle.dump(val_f1_list, file)

    pickle.dump(val_recall, file)
    pickle.dump(val_recall_list, file)

    pickle.dump(val_precision, file)
    pickle.dump(val_precision_list, file)

with open('performances.pkl', 'rb') as file:
    loss = pickle.load(file)

    val_acc = pickle.load(file)
    val_acc_list = pickle.load(file)

    val_f1 = pickle.load(file)
    val_f1_list = pickle.load(file)

    val_recall = pickle.load(file)
    val_recall_list = pickle.load(file)

    val_precision = pickle.load(file)
    val_precision_list = pickle.load(file)

val_performance1 = np.array(val_acc_list)
acc_mean = np.mean(val_performance1)
acc_std = np.std(val_performance1)
print("test acc mean is: %f" % acc_mean)

val_performance2 = np.array(val_f1_list)
f1_mean = np.mean(val_performance2)
f1_std = np.std(val_performance2)
print("test f1 mean is: %f" % f1_mean)

val_performance3 = np.array(val_recall_list)
recall_mean = np.mean(val_performance3)
recall_std = np.std(val_performance3)
print("test recall mean is: %f" %recall_mean)

val_performance4 = np.array(val_precision_list)
precision_mean = np.mean(val_performance4)
precision_std = np.std(val_performance4)
print("test precision mean is: %f" %precision_mean)

# the last performance
plt.subplot(1, 5, 1)
plt.plot(loss, label='Training Loss')
plt.title('Training Loss')
plt.legend()

plt.subplot(1, 5, 2)
plt.plot(val_acc, label='validation Acc')
plt.title('validation Acc')
plt.legend()

# the ten-fold performance of the val accuracy
plt.subplot(1, 5, 3)
plt.plot(val_f1, label='validation f1')
plt.title('validation f1')
plt.legend()

plt.subplot(1, 5, 4)
plt.plot(val_acc_list, label='ten-fold performance')
plt.title('validation Acc in ten-fold testing')
plt.legend()

plt.subplot(1, 5, 5)
plt.plot(val_f1_list, label='ten-fold performance')
plt.title('validation f1 in ten-fold testing')
plt.legend()

plt.show()