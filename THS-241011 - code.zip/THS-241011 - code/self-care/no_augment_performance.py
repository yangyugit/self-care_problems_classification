import pandas as pd
import numpy as np
import random
import pickle
import matplotlib.pyplot as plt
import time

import tensorflow as tf
from tensorflow.keras import backend as K
from tensorflow.keras.models import Model
from tensorflow.keras.layers import *
from tensorflow.keras.models import load_model
from tensorflow.keras.utils import to_categorical
from sklearn.model_selection import train_test_split
from sklearn.model_selection import KFold
from sklearn.preprocessing import OneHotEncoder, LabelEncoder

## data loading and augment
start_time = time.time()
data_file = '../dataset/SCADI.csv'
original_data = pd.read_csv(data_file)

extend_data = original_data # no augmentation of the dataset

## dataset constructing for training and testing the neural network
class_name = extend_data['Classes']
label_encoder = LabelEncoder()
label_value = label_encoder.fit_transform(class_name)
enc = OneHotEncoder()
one_hot = enc.fit_transform(label_value.reshape(-1, 1))
y_onehot = one_hot.toarray()
x = extend_data.drop(labels=['Classes'], axis=1).values
y = [np.argmax(one_hot) for one_hot in y_onehot]
y = np.asarray(y)
y = y.reshape((-1, 1))
data_set = np.concatenate((x, y), axis=1)
y_list = []
for item in y:
    for i in item:
        y_list.append(i)
dict = {}
set = set(y_list)
for item in set:
    dict.update({item: y_list.count(item)})

x_data = x
y_data = np.array(y_list)

# the alpha in focal loss function
list_base = [2, 2, 2, 2, 2, 2, 2]
list_all = list(dict.values())
global alpha_0
alpha_0 = (np.array(list_all) - np.array(list_base))/sum(np.array(list_all) - np.array(list_base)) + 1
alpha_0.shape = 7,1

def focal_loss(y_true, y_pred):
    epsilon = 1.e-7
    gamma = 2.0
    alpha = tf.cast(alpha_0, tf.float32)

    y_true = tf.cast(y_true, tf.float32)
    y_pred = tf.clip_by_value(y_pred, epsilon, 1. - epsilon)
    y_t = tf.multiply(y_true, y_pred) + tf.multiply(1-y_true, 1-y_pred)
    ce = -tf.math.log(y_t)
    weight = tf.pow(tf.subtract(1., y_t), gamma)
    fl = tf.matmul(tf.multiply(weight, ce), alpha)
    loss = tf.reduce_mean(fl)
    return loss

def f1(y_true, y_pred):
    def recall(y_true, y_pred):
        """Recall metric.

        Only computes a batch-wise average of recall.

        Computes the recall, a metric for multi-label classification of
        how many relevant items are selected.
        """
        true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
        possible_positives = K.sum(K.round(K.clip(y_true, 0, 1)))
        recall = true_positives / (possible_positives + K.epsilon())
        return recall

    def precision(y_true, y_pred):
        """Precision metric.

        Only computes a batch-wise average of precision.

        Computes the precision, a metric for multi-label classification of
        how many selected items are relevant.
        """
        true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
        predicted_positives = K.sum(K.round(K.clip(y_pred, 0, 1)))
        precision = true_positives / (predicted_positives + K.epsilon())
        return precision

    precision = precision(y_true, y_pred)
    recall = recall(y_true, y_pred)
    return 2 * ((precision * recall) / (precision + recall + K.epsilon()))

def recall_score(y_true, y_pred):
    """Recall metric.

    Only computes a batch-wise average of recall.

    Computes the recall, a metric for multi-label classification of
    how many relevant items are selected.
    """
    true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
    possible_positives = K.sum(K.round(K.clip(y_true, 0, 1)))
    recall = true_positives / (possible_positives + K.epsilon())
    return recall

def precision_score(y_true, y_pred):
    """Precision metric.

    Only computes a batch-wise average of precision.

    Computes the precision, a metric for multi-label classification of
    how many selected items are relevant.
    """
    true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
    predicted_positives = K.sum(K.round(K.clip(y_pred, 0, 1)))
    precision = true_positives / (predicted_positives + K.epsilon())
    return precision

val_acc_list = []; val_f1_list = []  # record the performance
val_recall_list = []; val_precision_list=[];

kf = KFold(n_splits=9, shuffle=True, random_state=1)

for train_index, test_index in kf.split(range(0,70)):
    x_train = x_data[train_index]
    x_test = x_data[test_index]

    y_train = y_data[train_index]
    y_test = y_data[test_index]

    y_train_onehot = y_onehot[train_index]
    y_test_onehot = y_onehot[test_index]

    # the embedding network
    embedding_size = 56    # set the embedding dimension
    input_layer = Input((205))
    x = Dense(200, activation="relu")(input_layer)
    x = Dense(150, activation="relu")(x)
    x = Dense(embedding_size, activation="relu")(x) # embedding size=100
    x = Dense(205, activation="relu")(x) # the input
    embedding_model = Model(input_layer, x)

    embedding_model.compile(loss='mse', optimizer='adam')
    # embedding_model.compile(loss='mae', optimizer='adam')
    history1 = embedding_model.fit(x_train, x_train, epochs=200, batch_size=32, verbose=2, validation_data=(x_test, x_test))
    # save and load the trained neural network
    # embedding_model.save("embedding_network", save_format="tf")
    # embedding_model = load_model("embedding_network", compile=False)

    # the focal loss model (for classification)
    input_layer = Input((embedding_size))
    midlle_value = Dense(100, activation="relu")(input_layer)
    midlle_value = Dense(50, activation="relu")(midlle_value)
    model_output = Dense(7, activation="softmax")(midlle_value) # the model output
    class_model = Model(input_layer, model_output)

    # the extractor model
    embedding_extractor = Model(inputs=embedding_model.input,
                                outputs=embedding_model.layers[-2].output)

    # train data
    embeddings_train = embedding_extractor.predict(x_train, verbose=1)
    # train data
    x_train = embeddings_train
    y_train = y_train_onehot

    # test data
    embeddings_test = embedding_extractor.predict(x_test, verbose=1)

    x_test = embeddings_test
    y_test = y_test_onehot

    class_model.compile(loss=focal_loss, optimizer="adam", metrics=['accuracy', recall_score, precision_score, f1])
    history = class_model.fit(x_train, y_train, epochs=200, batch_size=32, verbose=2, validation_data=(x_test, y_test))

    y_pred = class_model(x_test)

    # see the accuracy
    loss = history.history['loss']
    val_acc = history.history['val_accuracy']
    val_f1 = history.history['val_f1']
    val_recall = history.history['val_recall_score']
    val_precision = history.history['val_precision_score']

    val_acc_list.append(val_acc[-1])    # record
    val_f1_list.append(val_f1[-1])
    val_recall_list.append(val_recall[-1])
    val_precision_list.append(val_precision[-1])


val_performance1 = np.array(val_acc_list)
acc_mean = np.mean(val_performance1)
acc_std = np.std(val_performance1)
print("test acc mean is: %f" % acc_mean)

val_performance2 = np.array(val_f1_list)
f1_mean = np.mean(val_performance2)
f1_std = np.std(val_performance2)
print("test f1 mean is: %f" % f1_mean)

val_performance3 = np.array(val_recall_list)
recall_mean = np.mean(val_performance3)
recall_std = np.std(val_performance3)
print("test recall mean is: %f" %recall_mean)

val_performance4 = np.array(val_precision_list)
precision_mean = np.mean(val_performance4)
precision_std = np.std(val_performance4)
print("test precision mean is: %f" %precision_mean)

with open('56_no_augment.pkl', 'wb') as file:
    pickle.dump(loss, file)

    pickle.dump(val_acc, file)
    pickle.dump(val_acc_list, file)

    pickle.dump(val_f1, file)
    pickle.dump(val_f1_list, file)

    pickle.dump(val_recall, file)
    pickle.dump(val_recall_list, file)

    pickle.dump(val_precision, file)
    pickle.dump(val_precision_list, file)

with open('56_no_augment.pkl', 'rb') as file:
    loss = pickle.load(file)

    val_acc = pickle.load(file)
    val_acc_list = pickle.load(file)

    val_f1 = pickle.load(file)
    val_f1_list = pickle.load(file)

    val_recall = pickle.load(file)
    val_recall_list = pickle.load(file)

    val_precision = pickle.load(file)
    val_precision_list = pickle.load(file)

val_performance1 = np.array(val_acc_list)
acc_mean = np.mean(val_performance1)
acc_std = np.std(val_performance1)
print("test acc mean is: %f" % acc_mean)


val_performance2 = np.array(val_f1_list)
f1_mean = np.mean(val_performance2)
f1_std = np.std(val_performance2)
print("test f1 mean is: %f" % f1_mean)

val_performance3 = np.array(val_recall_list)
recall_mean = np.mean(val_performance3)
recall_std = np.std(val_performance3)
print("test recall mean is: %f" %recall_mean)

val_performance4 = np.array(val_precision_list)
precision_mean = np.mean(val_performance4)
precision_std = np.std(val_performance4)
print("test precision mean is: %f" %precision_mean)

# the last performance
plt.subplot(1, 5, 1)
plt.plot(loss, label='Training Loss')
plt.title('Training Loss')
plt.legend()

plt.subplot(1, 5, 2)
plt.plot(val_acc, label='validation Acc')
plt.title('validation Acc')
plt.legend()

# the ten-fold performance of the val accuracy
plt.subplot(1, 5, 3)
plt.plot(val_f1, label='validation f1')
plt.title('validation f1')
plt.legend()

plt.subplot(1, 5, 4)
plt.plot(val_acc_list, label='ten-fold performance')
plt.title('validation Acc in ten-fold testing')
plt.legend()

plt.subplot(1, 5, 5)
plt.plot(val_f1_list, label='ten-fold performance')
plt.title('validation f1 in ten-fold testing')
plt.legend()

plt.show()