import numpy as np
import pickle
import matplotlib.pyplot as plt
import matplotlib.ticker as mtick
with open('205_no_augment.pkl', 'rb') as file:
    loss = pickle.load(file)

    val_acc = pickle.load(file)
    val_acc_list = pickle.load(file)

    val_f1 = pickle.load(file)
    val_f1_list = pickle.load(file)

    val_recall = pickle.load(file)
    val_recall_list = pickle.load(file)

    val_precision = pickle.load(file)
    val_precision_list = pickle.load(file)

acc_205 = val_acc_list
pre_205 = val_precision_list
recall_205 = val_recall_list
f1_205 = val_f1_list

print('------------------205 dimensions -----------------:')
print(acc_205)
print("test acc mean is: %f" % np.mean(acc_205))
print("test acc std is: %f" % np.std(acc_205))
print(pre_205)
print("test precision mean is: %f" % np.mean(pre_205))
print("test precision std is: %f" % np.std(pre_205))
print(recall_205)
print("test recall mean is: %f" % np.mean(recall_205))
print("test recall std is: %f" % np.std(recall_205))
print(f1_205)
print("test f1 score mean is: %f" % np.mean(f1_205))
print("test f1 score std is: %f" % np.std(f1_205))


with open('34_no_augment.pkl', 'rb') as file:
    loss = pickle.load(file)

    val_acc = pickle.load(file)
    val_acc_list = pickle.load(file)

    val_f1 = pickle.load(file)
    val_f1_list = pickle.load(file)

    val_recall = pickle.load(file)
    val_recall_list = pickle.load(file)

    val_precision = pickle.load(file)
    val_precision_list = pickle.load(file)

acc_34 = val_acc_list
pre_34 = val_precision_list
recall_34 = val_recall_list
f1_34 = val_f1_list

print('------------------34 dimensions -----------------:')
print(acc_34)
print("test acc mean is: %f" % np.mean(acc_34))
print("test acc std is: %f" % np.std(acc_34))
print(pre_34)
print("test precision mean is: %f" % np.mean(pre_34))
print("test precision std is: %f" % np.std(pre_34))
print(recall_34)
print("test recall mean is: %f" % np.mean(recall_34))
print("test recall std is: %f" % np.std(recall_34))
print(f1_34)
print("test f1 score mean is: %f" % np.mean(f1_34))
print("test f1 score std is: %f" % np.std(f1_34))



with open('56_no_augment.pkl', 'rb') as file:
    loss = pickle.load(file)

    val_acc = pickle.load(file)
    val_acc_list = pickle.load(file)

    val_f1 = pickle.load(file)
    val_f1_list = pickle.load(file)

    val_recall = pickle.load(file)
    val_recall_list = pickle.load(file)

    val_precision = pickle.load(file)
    val_precision_list = pickle.load(file)

acc_56 = val_acc_list
pre_56 = val_precision_list
recall_56 = val_recall_list
f1_56 = val_f1_list

print('----------------56 dimensions-------------- :')
print(acc_56)
print("test acc mean is: %f" % np.mean(acc_56))
print("test acc std is: %f" % np.std(acc_56))
print(pre_56)
print("test precision mean is: %f" % np.mean(pre_56))
print("test precision std is: %f" % np.std(pre_56))
print(recall_56)
print("test recall mean is: %f" % np.mean(recall_56))
print("test recall std is: %f" % np.std(recall_56))
print(f1_56)
print("test f1 score mean is: %f" % np.mean(f1_56))
print("test f1 score std is: %f" % np.std(f1_56))

